import React from 'react'

export default function Library() {
  return (
    <div className='screen-container'>Library</div>
  )
}
