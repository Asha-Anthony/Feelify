import React from 'react'

export default function Emotions() {
  return (
    <div className='screen-container'>Emotions</div>
  )
}
